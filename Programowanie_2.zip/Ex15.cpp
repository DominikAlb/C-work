#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdio.h>
using namespace std;
#define MAX 100

class Employee {
    public :
        static int n;
        void print() {
            //cout << "Employee #" << n << " created";
        }
        Employee () {
            n++;
            cout << "Employee #" << n << " created" << endl;
        }
        ~Employee () {
            n--;
            cout << "Employee #" << n << " deleted" << endl;
        }
};
int Employee::n = 0;

int main() {
    Employee e[MAX];
    int i = 0;
    while (i < MAX) {
        //e.print();
        i++;
    }
    char a;
    cin>>a;
    return 0;
}
