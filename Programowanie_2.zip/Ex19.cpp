#include <iostream>

using namespace std;

class Triangle {
      public:
          float a;
          float b;
          float c;
                   
};

int main(){
    Triangle triangle = {4, 5, 6};
    cout<<triangle.a<<" "<<triangle.b<<" "<<triangle.c<<endl;
    char a;
    cin>>a;
    return 0;    
}
