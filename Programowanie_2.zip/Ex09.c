//Dominik Albiniak 01-04-2017
#include <stdio.h>
#include <stdlib.h>
struct node {
    int value;
    struct node *next;
    struct node *previous;     
};
struct node *ww = NULL;
void ADD(int x) {
    struct node *ws = malloc(sizeof(struct node));
    ws -> value = x;
    ws->next = ww;
    ww = ws;
}
void PRINT(struct node *ww) {
     
	struct node *Temp = ww;

	if (Temp->next) {
		PRINT(Temp->next);
	}
        printf("%i ", Temp->value);
}
int main() {
    int x;
    scanf ("%i", &x);
    while (x != 0) {
        ADD( x );
        scanf ("%i", &x);
    }
    PRINT (ww);
    return 0;   
}
