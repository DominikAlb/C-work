#include <iostream>

using namespace std;

class Account{
      public:
          float balance;
          int no;

        Account(float balance1, int no1){
             this->balance = balance1;
             this->no = no1;
        }

        void print(){
        cout<<"Balance = "<<balance<<endl;
        }
};

class TransactionProcessor {
      public:
          void transfer(Account ac1, Account ac2, float am) {
              ac1.balance -= am;
              ac2.balance += am;
          }
          friend class Account;
};

int main() {
    Account ac1 = Account(100000, 1);
    Account ac2 = Account(100, 2);
    TransactionProcessor t = TransactionProcessor();
    t.transfer(ac1, ac2, 750);


    return 0;
}
