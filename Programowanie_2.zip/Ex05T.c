//Dominik Albiniak 01-04-2015
#define MAX 15
#include <stdlib.h>
#include <stdio.h>
int main() {
    int *d = (int*)malloc(sizeof(int) * MAX);
    for (int i = 0; i < MAX; i++) {
        d[i] = i;
        *(d + i) = i;
    }
    for (int i = 0; i < MAX; i++) {
        printf("%d ", d[i]);
    }
    free(d);
    d = NULL;
    return 0;
}
