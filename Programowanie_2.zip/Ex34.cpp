#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
std::vector<string> Vec;
void myfunction (string i) {  // function:
  cout << ' ' << i;
}
int main() {

    string buf;
    cin >> buf;
    while (buf != "0") {
        Vec.push_back(buf);
        cin >> buf;
    }
    sort(Vec.begin(), Vec.end());
     // sort verified
     std::for_each(Vec.begin(), Vec.end(), myfunction);
}
