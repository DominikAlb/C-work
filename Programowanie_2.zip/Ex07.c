//Dominik Albiniak 01-04-2017
#include <stdio.h>
#include <stdlib.h>

int main() {
    int size;
    int second_size;
    int** heigth;
    scanf("%i", &size);
    heigth = malloc(sizeof(int*) * size);
    int i = 0;
    while (i < size) {
        scanf("%i", &second_size);
        int y = 1;
        *(heigth + i) = malloc(sizeof(int) * (second_size + 1));
        *(*(heigth + i)) = second_size;
        while (y <= second_size) {
            scanf("%i", &(*(*(heigth + i) + y)));
            y++;
        }
        i++;
    }
    i = 0;
    while(i < size) {
        int y = 1;
        while (y <= *(*(heigth + i))) {
            printf("%i ", *(*(heigth + i) + y));
            y++;  
        }
        printf("\n");
        free(*(heigth + i));
        i++;
    }
    free(heigth);
    
    return 0;
}
