
#include <iostream>
#include <algorithm>
#include <vector>
#include <ctime>
std::vector<float> Vec;
float treshold = 0.5;
int main() {
    using namespace std;
    Vec.push_back(0.5);
    srand(time(NULL));
    int n = rand() % 100;
    for (int i = 0; i < n; i++) {
        float x = (float)(rand() % 100) / 100;
        Vec.push_back(x);
    }

    std::for_each(Vec.begin(), Vec.end(),[&treshold](float a) {
        if (a >= treshold) {
            cout << a << endl;
        }
    });
    return 0;
}
