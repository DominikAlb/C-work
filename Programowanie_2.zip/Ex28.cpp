// Piotr Gabrielski
#include <deque>
#include <iostream>
using namespace std;
int main() {
    std::deque <int> deque;
    int num;
    while (true) {
        cout << "Podaj liczbe: ";
        cin >> num;
        if (num == 0) {
            if (deque.empty()) {
                break;
            } else {
                int top = deque.back();
                deque.pop_back();
                cout << top << endl;
            }
        } else {
            deque.push_back(num);
        }
    }
    return 0;
}
