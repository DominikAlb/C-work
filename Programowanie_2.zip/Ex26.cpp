// Dominik Albiniak
#include <vector>
#include <iostream>
using namespace std;
int main() {
    std::vector <int> vector;
    int num;
    while (true) {
        cout << "Podaj liczbe: ";
        cin >> num;
        if (num == 0) {
            if (vector.empty()) {
                break;
            } else {
                int top = vector.back();
                vector.pop_back();
                cout << top << endl;
            }
        } else {
            vector.push_back(num);
        }
    }
    return 0;
}
