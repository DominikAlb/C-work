//Dominik Albiniak 09.05.2017r
#include <stdio.h>
#include <stdlib.h>
#define UP 'w'
#define DOWN 's'
#define RIGHT 'd'
#define LEFT 'a'
struct localization {
    int x;
    int y;
    int where;
};
int check (struct localization*** way,struct localization* map, struct localization* player) {
    struct localization** hosp = *way;
    int i = 0;
    int j = 0;
    while (i < map->y) {
        while (j < map->x) {
            if (hosp[i][j + 1].x == player->x && hosp[i][j + 1].y == player->y) {
                return 1;
            }
            j++;
        }
        i++;
    }
    return 0;
}
void add(struct localization*** wayy, struct localization* map, struct localization* player, char c) {
    struct localization** way = *wayy;
    if (c == UP) {
        if (player->y == 0) {
            return;
        }
        player->y -= 1;
        if (check(&way, map, player) == 0) {
            ++(way[player->y][0].x);
            way[player->y] = realloc(way[player->y], (way[player->y][0].x + 1) * sizeof(struct localization));
            way[player->y][(way[player->y][0].x)].x = player->x;
            way[player->y][(way[player->y][0].x)].y = player->y;
            way[player->y][(way[player->y][0].x)].where = 8;
        }
    } else if (c == DOWN) {
        if (player->y + 1 >= map->y) {
            map->y += 1;
            way = realloc(way, (map->y) * sizeof(struct localization*));
            way[player->y + 1] = malloc(2 * sizeof(struct localization));
            way[player->y + 1][0].x = 1;
        }
        player->y += 1;
        if (check(&way, map, player) == 0) {
            ++way[player->y][0].x;
            way[player->y] = realloc(way[player->y], (way[player->y][0].x + 1) * sizeof(struct localization));
            way[player->y][(way[player->y][0].x)].x = player->x;
            way[player->y][(way[player->y][0].x)].y = player->y;
            way[player->y][(way[player->y][0].x)].where = 2;
        }
    } else if (c == RIGHT) {
        if (player->x + 1 >= map->x) {
            map->x += 1;
        }
        player->x += 1;
        if (check(&way, map, player) == 0) {
            ++(way[player->y][0].x);
            way[player->y] = realloc(way[player->y], (way[player->y][0].x + 1) * sizeof(struct localization));
            way[player->y][(way[player->y][0].x)].x = player->x;
            way[player->y][(way[player->y][0].x)].y = player->y;
            way[player->y][(way[player->y][0].x)].where = 6;
        }
    } else if (c == LEFT) {
        if (player->x == 0) {
            return;
        }
        player->x -= 1;
        if (check(&way, map, player) == 0) {
            ++(way[player->y][0].x);
            way[player->y] = realloc(way[player->y], (way[player->y][0].x + 1) * sizeof(struct localization));
            way[player->y][(way[player->y][0].x)].x = player->x;
            way[player->y][(way[player->y][0].x)].y = player->y;
            way[player->y][(way[player->y][0].x)].where = 4;
        }
    }
    *wayy = way;
}
int part(struct localization*** part, int i,int j, struct localization* map) {
    int k = 0;
    struct localization** pa = *part;
    while (k < pa[i][0].x) {
        if (pa[i][k + 1].x == j && pa[i][k + 1].y == i)
            return pa[i][k + 1].where;
        k++;
    }
    return -1;
}
void print_map (struct localization*** path, struct localization* player, struct localization* map, char prev, char now) {
    struct localization** pat = *path;
    int i = 0;
    int j = 0;
    while (i < map->y) {
        j = 0;
        while (j < map->x) {
            //printf("%i %i\n", i, k);
            int value = part(path, i,j, map);
            if (i == player->y && j == player->x) {
                printf("x ");
                //l++;
            } else if (value != -1) {
                    printf("o ");
            } else {
                printf("  ");
            }
            j++;
        }
        printf("\n");
        //printf("!%i", i);
        i++;
        j = 0;
    }
    //printf("\nEND\n");
}
void delete_all(struct localization*** path, struct localization* map, struct localization* player) {
    int i = 0;
    int j = 0;
    struct localization** endd = *path;

    while (i < map->y) {
        free(endd[i]);
        i++;
        j = 0;
    }
    free(endd);
    free(map);
    free(player);
}
int main() {
    struct localization* player = malloc(sizeof(struct localization));
    player->x = 0;
    player->y = 0;
    struct localization* map_size = malloc(sizeof(struct localization));
    map_size->x = 1;
    map_size->y = 1;

    struct localization** path = (struct localization**)malloc(map_size->y * sizeof(struct localization*));
    *(path) = (struct localization*)malloc((map_size->x + 1) * sizeof(struct localization));
    path[0][1].x = 0;
    path[0][1].y = 0;
    path[0][0].x = 1;
    char c;
    char prev;
    scanf("\t %c", &c);
    if (c == 's')
        prev = 'd';
    else if (c == 'd')
        prev = 's';
    else
        prev = 'Q';
    while (c != 'x') {
        add(&path, map_size, player, c);
        print_map(&path, player, map_size, prev, c);
        prev = c;
        scanf("\t %c", &c);
    }
    delete_all(&path, map_size, player);
    return 0;
}
