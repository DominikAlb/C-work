//Dominik Albiniak 01-04-2015
#include <stdio.h>
#include <stdlib.h>

int main () {
    int* tab;
    int value = 0;
    int i;
    scanf("%i", &i);
    while (i != 0) {
        if (i > 0) {
            if (value == 0) {
                tab = (int*)(malloc(sizeof(int) * (++value)));
                (*tab) = i;
            } else {
                int* newtab = (int*)malloc(sizeof(int) * (++value));
                int k = 0;
                while (k < value - 1) {
                    *(newtab + k) = *(tab + k);
                    k++;  
                }
                free (tab);
                tab = newtab;
                k = value - 2;
                while (k >= 0 && k < *(tab + k)) {
                    *(tab + k + 1) = *(tab + k);  
                    k--;
                }
                *(tab + k + 1) = i;
            }
        } else {
            int k;
            i = -i;
            k = i - 1;
            while (k < value - 1) {
                *(tab + k) = *(tab + k + 1);
                k++;     
            }
            value--;
            int* newtab = (int*)malloc(sizeof(int) * (value));
            int z = 0;
            while (z < value - 1) {
                *(newtab + z) = *(tab + z);
                z++;  
            }
            free(tab);
            newtab = tab;
            
        }
            scanf("%i", &i);
            free(tab);
    }
 return 0;   
}
