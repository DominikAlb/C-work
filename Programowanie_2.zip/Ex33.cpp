#include <iostream>
int main() {
    int memory = 0;
    int number;
    int errorMemory;
    std::cin >> errorMemory;
    std::cin >> number;
    while (number > 0) {
        int array[number];
        for (int i = 0; i < number; i++) {
            std::cin >> array[i];
            if (errorMemory == memory) memory++;
            std::cout << array[i] << " located at: " << memory++ << std::endl;
        }
        std::cin >> number;
    }
    return 0;
}
