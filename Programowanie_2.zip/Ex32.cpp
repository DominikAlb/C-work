#include <iostream>
#define MAX 100
int main() {
    int zapalki[MAX];
    for (int i = 0; i < MAX; i++) {
        zapalki[i] = 0;
    }
    int place, value;
    std::cin >> place >> value;
    while(place > -1) {
        for (int i = place; i < value + place && i < MAX; i++) {
            zapalki[i] += 1;
        }
        std::cin >> place >> value;
    }
    for (int i = 0; i < MAX; i++) {
        std::cout << zapalki[i] << " ";
        if (i%15==0) std::cout << std::endl;
    }
    std::cout << std::endl;
    return 0;
}
