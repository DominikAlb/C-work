//Dominik Albiniak 01-04-2017
#include <stdio.h>
#include <stdlib.h>
typedef struct el_list {
    int val;
    struct el_list *next;
} el;
void add(el **list, int wartosc) {
    el *neww = (el*)malloc(sizeof(el));
    neww->val = wartosc;
    if (*list == NULL)
    {
       *list = neww;
    }
    else
    {
        neww->next = (*list)->next;
    }
    (*list)->next = neww;
}
void print(el *list) {
    el *wsk = list;
    int max = list->val;
    el *lol = list;
    el *pop;
    while (wsk->next != list) {
        while(list != wsk->next)
        {
            //printf("%i %i %i\n", wsk->next->val, max, list->val);
            if (wsk->next->val > max) {
                max = wsk->next->val;
                lol = wsk->next;
                pop = wsk;
            }
            wsk = wsk->next;
        }
        if (lol != list) {
            printf("%i ",max);
            el *zamien = lol->next;
            free(lol);
            pop->next = zamien;
            wsk = list;
            max = list->val;
            lol = list;
        } else {
            //printf("b%i ", wsk->val);
            //el *zmiana = list;
            //list = list->next;
            //list = zmiana;
            wsk = list->next;
            max = list->next->val;
            lol = list->next;
            list = list->next;
            //free(zmiana);
        }
    }
    printf("%i", list->val);
    free(list);

}
int main() {
    el *lista = NULL;
    int x;
    scanf ("%i", &x);
    while (x != 0) {
        add(&lista, x);
        scanf ("%i", &x);
    }
    print(lista);
    return 0;
}
