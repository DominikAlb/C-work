#include <iostream>

using namespace std;

class Engine {
      public:
             virtual void start () = 0;
             virtual void stop() = 0;
};

class ICE: public Engine {
      public:
          void start(){};
          void stop(){};
          int cylinders;
          ICE(int cylinder): Engine() {
              cylinders = cylinder;
              cout<<"Created Engine with "<<cylinders<<" cylinders"<<endl;
          }
};

class Electric: public Engine {
      public:
          void start(){};
          void stop(){};   
          int colls;
          Electric (int col): Engine(){
              colls = col;
              cout<<"Created Electric with "<<colls<<" colls\n";          
          }
};

class Diesel: public ICE {
      public:
          void start(){};
          void stop(){};
          Diesel(int cylinder): ICE(cylinder){}
};
      
int main() {
    Electric el = Electric(4);

    char a;
    cin>>a;
    
    return 0;    
}
