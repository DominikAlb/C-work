// Dominik Albiniak
#include <list>
#include <iostream>
using namespace std;
int main() {
    std::list <int> list;
    int num;
    while (true) {
        cout << "Podaj liczbe: ";
        cin >> num;
        if (num == 0) {
            if (list.empty()) {
                break;
            } else {
                int top = list.back();
                list.pop_back();
                cout << top << endl;
            }
        } else {
            list.push_back(num);
        }
    }
    return 0;
}
