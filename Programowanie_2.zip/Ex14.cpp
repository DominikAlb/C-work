#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdio.h>


using namespace std;

 class Person {
     public:
         string firstName;
         string lastName;    
         
         string getStringF () {
             return firstName;
         }
         void setStringF (string in) {
             firstName = in;
         }
         string getStringL () {
             return lastName;
         }
         void setStringL (string in) {
             lastName = in;
         }
         Person (string first, string last) {
             firstName = first;
             lastName = last;
         }
         ~Person() {}
         void print () {
             cout << firstName << endl;
             cout << lastName << endl;
         }
 };
 class Organization {
     public:
         string name;
         int year;
         Person** per;// = (Person**)malloc(sizeof(Person*))
         int size;
         Organization (string nName, int yYear) {
             name = nName;
             year = yYear;
             size = 0;
         }
         ~Organization () {}
         void addEmployee (Person *p) {
             per = (Person**)realloc(per,(++size) * sizeof(Person*));
             per[size - 1] = p;
         }
         void removeEmployee (Person *p) {
             int i = 0;
             while(*(per + i) != p) {i++;}
             Person *temp = per[i];
             per[i] = per[size - 1];
             per[size - 1] = temp;
             per = (Person**)realloc(per, (--size) * sizeof(Person*));
         }
         void showEmployee () {
             int i = 0;
             while (i < size) {
                 per[i]->print();
                 i++;
             }
         }
               
 };
 int main () {
     Organization *ONZ = new Organization ("ONZ", 1945);
     Person *per1 = new Person("Sir Gladwyn", "Jebb");
     Person *per2 = new Person("Trygve", "Lie");
     Person *per3 = new Person("Dag", "Hammarskj�ld");
     ONZ -> addEmployee (per1);
     ONZ -> addEmployee (per2);
     ONZ -> addEmployee (per3);
     ONZ -> removeEmployee (per2);
     ONZ -> showEmployee ();
     char a;
     cin >> a;
     return 0;    
 }
