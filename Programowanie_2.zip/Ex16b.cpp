//Dominik Albiniak
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PI 3.14

using namespace std;
class Shape {
    public: 
        virtual float area () = 0;
        virtual float circumference () = 0;
};
class Circle: public Shape {
    public:
    float r;
    Circle (float r) {
        this -> r = r;
        print();
    }
    float area () {
        return PI * r * r;
    }
    float circumference () {
        return 2 * PI * r;
    }
    void print() {
        cout << area() << endl;
        cout << circumference() << endl;
    }
};
class Rectangle: public Shape {
    public:
    float x;
    float y; 
    Rectangle (float x, float y) {
        this -> x = x;
        this -> y = y;
        print();
    }
    float area () {
        return x * y;
    }
    float circumference () {
        return 2*x + 2*y;
    }
    void print() {
        cout << area() << endl;
        cout << circumference() << endl;
    }
};
class Triangle: public Shape {
    public:
    float x;
    float y;
    float z;
    Triangle (float x, float y, float z) {
        this -> x = x;
        this -> y = y;
        this -> z = z;
        print();
    }
    float area () {
        float p = 0.5 * (x + y + z) ;
        return sqrt(p*(p - x)*(p - y)*(p - z));
    }
    float circumference () {
        return x + y + z;
    }
    void print() {
        cout << area() << endl;
        cout << circumference() << endl;
    }
};
class Square: public Rectangle {
    public:
    Square (float x): Rectangle (x, x) {}
};
int main () {
    //Shape *s = new Shape();
    Triangle *t = new Triangle(3, 4, 5);
    Rectangle *r = new Rectangle (6 , 7);
    Square *q = new Square (2);
    Circle *c = new Circle (10);
    delete t;
    delete r;
    delete q;
    delete c;
    //char f;
    //cin>>f;
    return 0;
}
