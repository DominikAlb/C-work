//Dominik Albiniak, 2017-03-10
#include <iostream>
#define WIDTH 20
#define HEIGHT 15

int main() {
    for (int i = 0; i < WIDTH; i++) {
        for (int j = 0; j < HEIGHT; j++) {
            std::cout << ".";
        }
        std::cout << "\n";
    }
    return 0;
}
