//Dominik Albiniak, 2017-03-11
#include <iostream>
#include <math.h>
#define WIDTH 20
int main() {
    using std::cout;

    bool direction = true;
    int x = 0;
    int y = 0;
    while (true) {
        if (direction) {
            for (int i = 0; i < x; i++) {
                cout << ".";
            }
            if ((unsigned long long)(pow(2, y)) <= 0) {
                y = 4;
            }
            cout << (unsigned long long)(pow(2, y++)) % 10;
            x++;
            for (int i = x; i < WIDTH; i++) {
                cout << ".";
            }
            if (x == WIDTH) {
            direction = false;
            x -= 2;
            }

            cout << "\n";
        } else {
            for (int i = 0; i < x; i++) {
                cout << ".";
            }
            if ((unsigned long long)(pow(2, y)) <= 0) {
                y = 4;
            }
            cout << (unsigned long long)(pow(2, y++)) % 10;
            for (int i = x; i < WIDTH - 1; i++) {
                cout << ".";
            }
            x--;
            if (x == 0) {
                direction = true;
            }

            cout << "\n";
        }
    }

    return 0;
}

