#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
std::vector<int> X;
std::vector<int> Y;
void f (int a, int b) {  // function:
  cout << a * b << endl;
}
int main(){
    int x, y;
    cin >> x >> y;
    for (int i = 0; i < x; i++) {
        X.push_back(i);
    }
    for (int i = 0; i < y; i++) {
        Y.push_back(i * i);
    }
    std::for_each(X.begin(), X.end(), [&x](int a) {
        std::for_each(Y.begin(), Y.end(), [&y](int b)) {
            cout << a * b << endl;
        }
    });

}
