//Dominik Albiniak, 2017-03-11
#include <iostream>
#define WIDTH 20
int main() {
    using std::cout;

    bool direction = true;
    int x = 0;
    while (true) {
        if (direction) {
            for (int i = 0; i < x; i++) {
                cout << ".";
            }
            cout << "*";
            x++;
            for (int i = x; i < WIDTH; i++) {
                cout << ".";
            }
            if (x == WIDTH) {
            direction = false;
            x -= 2;
            }
            cout << "\n";
        } else {
            for (int i = 0; i < x; i++) {
                cout << ".";
            }
            cout << "*";
            for (int i = x; i < WIDTH - 1; i++) {
                cout << ".";
            }
            x--;
            if (x == 0) {
                direction = true;
            }
            cout << "\n";
        }
    }

    return 0;
}

