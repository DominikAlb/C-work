//Dominik Albiniak, 2017-03-11
#include <iostream>
#define WIDTH 20
int main() {
    using std::cout;

    bool direction = true;
    int x = 0;
    unsigned long long fib1 = 1, fib2 = 0;
    while (true) {
        if (direction) {
            for (int i = 0; i < x; i++) {
                cout << ".";
            }
            cout << (unsigned long long)((fib1 + fib2)) % 10;
            std::swap (fib1, fib2);
            fib2 += fib1;
            x++;
            for (int i = x; i < WIDTH; i++) {
                cout << ".";
            }
            if (x == WIDTH) {
            direction = false;
            x -= 2;
            }
            cout << "\n";
        } else {
            for (int i = 0; i < x; i++) {
                cout << ".";
            }
            cout << (unsigned int)((fib1 + fib2)) % 10;
            std::swap (fib1, fib2);
            fib2 += fib1;
            for (int i = x; i < WIDTH - 1; i++) {
                cout << ".";
            }
            x--;
            if (x == 0) {
                direction = true;
            }
            cout << "\n";
        }
    }

    return 0;
}

