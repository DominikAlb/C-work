#include <iostream>
#include <map>
#include <exception>
#include <stdexcept>
using namespace std;
int main() {
    std::map<int, int> Map;
    int x,y;
    cin >> x;
    while (true) {
        if (x != 0) {
            cin >> y;
            std::map<int,int>::iterator it = Map.begin();
            if(!Map.empty()) {
                try {
                    for (it=Map.begin(); it!=Map.end(); ++it)
                        if(it->first == x && it->second != y)
                            throw std::invalid_argument("invalid number");
                } catch(std::exception &e) {
                    cout << e.what() << endl;
                }
            }
            Map.insert(std::pair<int, int> (x, y));
        }
        cin >> x;
    }
    return 0;
}
