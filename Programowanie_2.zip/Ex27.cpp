// Dominik Albiniak
#include <queue>
#include <iostream>
using namespace std;
int main() {
    queue <int> queue;
    int num;
    while (true) {
        cout << "Podaj liczbe: ";
        cin >> num;
        if (num == 0) {
            if (queue.empty()) {
                break;
            } else {
                int top = queue.front();
                queue.pop();
                cout << top << endl;
            }
        } else {
            queue.push(num);
        }
    }
    return 0;
}
