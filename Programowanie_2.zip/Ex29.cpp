// Dominik Albiniak
#include <set>
#include <iostream>
using namespace std;
std::set <int> sett;
int main() {
    int num;
    while (true) {
        cout << "Podaj liczbe: ";
        cin >> num;
        if (sett.find(num) != sett.end()) {
            cout << "JUZ BYLO PRZEGRALES" << endl;
            break;
        } else {
            sett.insert(num);
        }
    }
    return 0;
}
