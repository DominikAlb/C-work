//Dominik Albiniak 01-04-2015
#include <stdlib.h>
#include <stdio.h>
int main() {
    int size;
    scanf("%d", &size);
    int* tab = malloc(sizeof(int) * size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &(*(tab + i)));
    }
    for (int i = 0; i < size; i++) {
        printf("%d ", *(tab + i));
    }
    free(tab);
    tab = NULL;
}
