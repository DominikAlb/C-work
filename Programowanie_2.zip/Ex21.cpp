#include <iostream>

using namespace std;

class LandAnimal{
      public:
         int nose;
};

class WaterAnimal{
      public:
          int nose;
};

class Hippo:public LandAnimal, WaterAnimal {
      Hippo(int a) {
        LandAnimal::nose = a;
        WaterAnimal::nose = 0;
      }
      Hippo();
};

int main() {
    return 0;
}
