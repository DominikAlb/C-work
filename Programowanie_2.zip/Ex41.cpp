#include <exception>
#include <iostream>
#include <stdexcept>

void f(int a) {
    if (a == 0) {
        throw std::invalid_argument("value cannot be 0");
    }
}
int main() {
    try {
        int *arr = new int[1024 * 1024 * 1024];
        f(0);
    } catch(std::exception &e) {
        std::cout << e.what() << std::endl;
    }
    return 0;
}
