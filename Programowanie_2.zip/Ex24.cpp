// Dominik Albiniak
#include <stack>
#include <iostream>
using namespace std;
int main() {
    std::stack <int> stack;
    int num;
    while (true) {
        cout << "Podaj liczbe: ";
        cin >> num;
        if (num == 0) {
            if (stack.empty()) {
                break;
            } else {
                int top = stack.top();
                stack.pop();
                cout << top << endl;
            }
        } else {
            stack.push(num);
        }
    }
    return 0;
}
