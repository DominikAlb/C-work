#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
using namespace std;
class Shape {
    public:
        float area () {
            return 0;
        }
        float circumference () {
            return 0;
        }
        float width;
        float height;
};
class Circle: public Shape {
    public:
    Circle (float x) {
        cout << area(x) << endl;
        cout << circumference(x) << endl;
    }
    float area (float x) {
        return 3.14 * x * x;
    }
    float circumference (float x) {
        return 2 * 3.14 * x;
    }
};
class Rectangle: public Shape {
    public:
    Rectangle (float x, float y) {
        cout << area(x, y) << endl;
        cout << circumference(x, y) << endl;
    }
    float area (float x, float y) {
        return x * y;
    }
    float circumference (float x, float y) {
        return 2*x + 2*y;
    }
};
class Triangle: public Shape {
    public:
    Triangle (float x, float y, float z) {
        cout << area(x, y, z) << endl;
        cout << circumference(x, y, z) << endl;
    }
    float area (float x, float y, float z) {
        float p = 0.5 * (x + y + z) ;
        return sqrt(p*(p - x)*(p - y)*(p - z));
    }
    float circumference (float x, float y, float z) {
        return x + y + z;
    }
};
class Square: public Rectangle {
    public:
    Square (float x): Rectangle (x, x) {}
};
int main() {
return 0;}
