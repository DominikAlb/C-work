//Dominik Albiniak 01-04-2017
#include <stdio.h>
#include <stdlib.h>

int main() {
    int size, size_char, size2;
    int second_size;
    char** city_names;
    char* city;
    int i;
    scanf("%i", &size2);
    i = 0;
    scanf("%i", &size2);
    city_names = malloc(sizeof(char*) * size2);
    int*** SSCI = malloc(sizeof(int**) * size2);
    SSCI = malloc(sizeof(int**) * size2);
    for(int value = 0; value < size2; value++) {
        
        scanf("%s",  &(*(city_names + value)));
        scanf("%i", &size);
        (*(SSCI + value)) = malloc(sizeof(int*) * size);
        i = 0;
        while (i < size) {
            scanf("%i", &second_size);
            int y = 1;
            (*(*(SSCI + value) + i)) = (int*)malloc(sizeof(int)* (second_size + 1));
            *(*(*(SSCI + value) + i) + 0) = second_size;
            while (y <= second_size) {
                scanf("%i", &(*(*(*(SSCI + value) + i) + y)));
                y++;
            }
            i++;
        }
    }
    for (int x = 0; x < size2; x++) {
        printf("%s", *(city_names + x));
        for(int y = 0; y < size; y++) {
            for (int z = 1; z <= *(*(*(SSCI + x)+y)); z++) {
               printf("%i", *(*(*(SSCI + x) + y) + z));
            }    
            printf("\n");
            free((*(*(SSCI + x) + y)));
        }
        free((*(*(SSCI + x))));
        free((*(*(city_names + x))));
    }
    free(SSCI);
    free(city_names);
    
    return 0;
}
