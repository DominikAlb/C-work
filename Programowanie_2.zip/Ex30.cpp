//Dominik Albiniak 05-05-2017
#include <iostream>
#include <set>
template < class T, class S>
class Pair{
      public:
      T x;
      S y;
};
template < class typ>
class MyComparator {
      
      public:
          bool operator() (const typ& c1, const typ& c2) {
               if (c1 == c2) {
                   return false;
               } else {
                   return true;
               }
          }
};
bool fncomp (Pair<int, int> a, Pair<int, int> b) {
     return !(a.x == b.x && a.y == b.y);    
}
int main ()
{
  bool(*fn_pt)(Pair<int, int> a,Pair<int, int> b) = fncomp;
  std::set<Pair<int, int>,bool(*)(Pair<int, int>,Pair<int, int>)> set (fn_pt);
  int x, y;
  Pair<int, int> p;
  do {
      std::cin >> x >> y;
      } while (set.insert(p).second);
      system ("pause");
  return 0;
}
