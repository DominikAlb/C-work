#include <iostream>
#include <algorithm>
#include <vector>
std::vector<int> vec;
int main() {
	int x;
	std::cin >> x;
	while (x != 0) {
		vec.push_back(x);
		std::cin >> x;
	}

	return 0;
}
