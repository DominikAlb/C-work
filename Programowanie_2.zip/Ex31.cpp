//Dominik Albiniak 05-05-2017
#include <iostream>
#include <set>
#include <stdio.h>
#include <ctype.h>

class MyComparator {
      public:
          bool operator() (const char& c1, const char& c2) {
               if (c1 == c2 || c1 + 32 == c2 || c1 - 32 == c2) {
                   return false;
               } else {
                   return true;
               }
          }
};
void fncomp (char* lhs) {
     if (islower(*lhs)) *lhs=toupper(*lhs);
}

struct classcomp {
  bool operator() (const char& lhs, const char& rhs) const
  {return lhs==rhs;}
};
int main ()
{
  std::set<char> set;

  char number;
    while (true) {
        std::cout << "Podaj znak\n";
        std::cin >> number;
        fncomp(&number);
        if (set.find(number) != set.end()) {
           std::cout << "JUZ BYLO!\n";
           break;
        } else {
        set.insert(number);
        }
    }
    char c;
    std::cin >> c;
  return 0;
}
