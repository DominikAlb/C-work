#include <iostream>
#include <string>
#include <stdlib.h>

using namespace std;

 class Person {
     public:
         string firstName;
         string lastName;    
         
         string getStringF () {
             return firstName;
         }
         void setStringF (string in) {
             firstName = in;
         }
         string getStringL () {
             return lastName;
         }
         void setStringL (string in) {
             lastName = in;
         }
         Person (string first, string last) {
             firstName = first;
             lastName = last;
         }
         ~Person() {}
         void print () {
             cout << firstName << endl;
             cout << lastName << endl;
         }
 };
 class Organization {
     public:
         string name;      
 };
 int main () {
     
     Person *p = new Person ("Jan", "Kowalski");
     p -> print();
     delete p;
     char a;
     cin >> a;
     return 0;    
 }
