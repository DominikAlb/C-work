#include <iostream>
#include <algorithm>
#include <vector>
#include <ctime>
std::vector<float> Vec;
int j = 0;
void setCout (float i) {
    std::cout << i << " ";
    if(j++ >= 10) {
        j -= 10;
        std::cout << std::endl;
    }
}
int main() {
    using namespace std;
    srand(time(NULL));
    int n = rand() % 100;
    for (int i = 0; i < n; i++) {
        float x = (float)(rand() % 100) / 100;
        Vec.push_back(x);
    }
    std::for_each(Vec.begin(), Vec.end(), setCout);
    return 0;
}
